// Netlify Function achter de knop "Data verversen": haalt de bronnen direct op en
// geeft verse waarden, scores en historie terug. Bereikbaar op /api/live.
import { collectAll } from '../lib/collect.mts'

export default async (req: Request) => {
  // Drempels en richting per indicator komen uit de gepubliceerde overview.json,
  // zodat Python (dagelijkse update) en deze functie dezelfde instellingen gebruiken.
  const overviewUrl = new URL('/data/overview.json', req.url)
  let meta: Record<string, any> = {}
  try {
    const ov = await (await fetch(overviewUrl)).json()
    for (const ind of ov.indicators) meta[ind.id] = ind
  } catch {
    return Response.json({ error: 'De instellingen van de indicatoren konden niet worden geladen.' }, { status: 502 })
  }

  const result = await collectAll(meta)
  if (!Object.keys(result.records).length) {
    return Response.json({ error: 'Geen enkele bron gaf antwoord. Probeer het later opnieuw.', errors: result.errors }, { status: 502 })
  }

  return Response.json(result, {
    headers: {
      // Browsers vragen altijd opnieuw; het CDN bewaart het antwoord 5 minuten,
      // zodat veel klikken kort na elkaar de bronnen niet overbelasten.
      'Cache-Control': 'public, max-age=0, must-revalidate',
      'Netlify-CDN-Cache-Control': 'public, durable, s-maxage=300, stale-while-revalidate=60',
    },
  })
}

export const config = { path: '/api/live', method: 'GET' }
